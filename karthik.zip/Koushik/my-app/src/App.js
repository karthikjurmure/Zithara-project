import React, { useEffect, useState } from 'react';

function App() {
  const [data, setData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('date');
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage] = useState(20);

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    try {
      const response = await fetch('http://localhost:3002/data');
      const data = await response.json();
      setData(data);
    } catch (error) {
      console.error('Error fetching data', error);
    }
  }

  function formatDateAndTime(datetime) {
    const date = new Date(datetime);
    const formattedDate = date.toLocaleDateString();
    const hours = date.getHours().toString().padStart(2, '0'); // Ensure two digits
    const minutes = date.getMinutes().toString().padStart(2, '0'); // Ensure two digits
    const formattedTime = `${hours}:${minutes}`;
    return { formattedDate, formattedTime };
  }

  function handleSearch(e) {
    setSearchTerm(e.target.value);
    setCurrentPage(1); // Reset pagination to first page when searching
  }

  function handleSort(column) {
    // If the same column is clicked again, toggle the sorting order
    if (sortBy === column + '_asc') {
      setSortBy(column + '_desc');
    } else {
      setSortBy(column + '_asc');
    }
  }
  

  function paginate(data) {
    const indexOfLastRecord = currentPage * recordsPerPage;
    const indexOfFirstRecord = indexOfLastRecord - recordsPerPage;
    return data.slice(indexOfFirstRecord, indexOfLastRecord);
  }

  function renderTable() {
    let filteredData = data.filter(
      item =>
        item.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.location.toLowerCase().includes(searchTerm.toLowerCase())
    );
  
    // Sort data based on the sortBy state
    if (sortBy === 'sno_asc') {
      filteredData.sort((a, b) => a.sno - b.sno);
    } else if (sortBy === 'sno_desc') {
      filteredData.sort((a, b) => b.sno - a.sno);
    } else if (sortBy === 'date_asc') {
      filteredData.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
    } else if (sortBy === 'date_desc') {
      filteredData.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    } else if (sortBy === 'time_asc') {
      filteredData.sort((a, b) => {
        const timeA = new Date(a.created_at).toLocaleTimeString('en-US', {hour12: false});
        const timeB = new Date(b.created_at).toLocaleTimeString('en-US', {hour12: false});
        return timeA.localeCompare(timeB);
      });
    } else if (sortBy === 'time_desc') {
      filteredData.sort((a, b) => {
        const timeA = new Date(a.created_at).toLocaleTimeString('en-US', {hour12: false});
        const timeB = new Date(b.created_at).toLocaleTimeString('en-US', {hour12: false});
        return timeB.localeCompare(timeA);
      });
    }
  
    const paginatedData = paginate(filteredData);
  
    return (
      <tbody>
        {paginatedData.map((row, index) => (
          <tr key={index}>
            <td style={styles.tableCell}>{row.sno}</td>
            <td style={styles.tableCell}>{row.customer_name}</td>
            <td style={styles.tableCell}>{row.age}</td>
            <td style={styles.tableCell}>{row.phone}</td>
            <td style={styles.tableCell}>{row.location}</td>
            <td style={styles.tableCell}>{formatDateAndTime(row.created_at).formattedDate}</td>
            <td style={styles.tableCell}>{formatDateAndTime(row.created_at).formattedTime}</td>
          </tr>
        ))}
      </tbody>
    );
  }

  function renderPagination() {
    const totalFilteredRecords = data.filter(
      item =>
        item.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.location.toLowerCase().includes(searchTerm.toLowerCase())
    ).length;
  
    const totalPages = Math.ceil(totalFilteredRecords / recordsPerPage);
  
    if (totalPages <= 1) {
      return null; // Don't render pagination if there's only one page or less
    }
  
    const pageNumbers = [];
    for (let i = 1; i <= totalPages; i++) {
      pageNumbers.push(i);
    }
  
    return (
      <div className="pagination" style={styles.paginationContainer}>
        {pageNumbers.map(number => (
          <button key={number} onClick={() => setCurrentPage(number)} style={styles.paginationButton}>
            {number}
          </button>
        ))}
      </div>
    );
  }
  
  return (
    <div className="App" style={styles.container}>
      <input
        type="text"
        placeholder="Search by name or location..."
        value={searchTerm}
        onChange={handleSearch}
        style={styles.searchInput}
      />
      <table style={styles.table}>
        <thead>
          <tr>
          <th style={styles.tableHeader}>
  Sno
  {/* Symbol for sorting */}
  <button onClick={() => handleSort('sno')} style={styles.sortButton}>
    {sortBy === 'sno_asc' ? '▲' : '▼'}
  </button>
</th>
            <th style={styles.tableHeader} onClick={() => handleSort('customer_name')}>Customer Name</th>
            <th style={styles.tableHeader} onClick={() => handleSort('age')}>Age</th>
            <th style={styles.tableHeader} onClick={() => handleSort('phone')}>Phone</th>
            <th style={styles.tableHeader} onClick={() => handleSort('location')}>Location</th>
            <th style={styles.tableHeader}>
              Date
              {/* Symbol for sorting */}
              <button onClick={() => handleSort('date')} style={styles.sortButton}>{sortBy === 'date_asc' ? '▲' : '▼'}</button>
            </th>
            <th style={styles.tableHeader}>
              Time
              {/* Symbol for sorting */}
              <button onClick={() => handleSort('time')} style={styles.sortButton}>{sortBy === 'time_asc' ? '▲' : '▼'}</button>
            </th>
          </tr>
        </thead>
        {renderTable()}
      </table>
      {renderPagination()}
    </div>
  );
  }  
export default App;

const styles = {
  container: {
    backgroundColor: '#f0f0f0',
    padding: '20px',
    borderRadius: '5px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
  },
  searchInput: {
    width: '100%',
    padding: '10px',
    fontSize: '16px',
    marginBottom: '20px',
    border: '2px solid #ccc',
    borderRadius: '5px',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
  },
  tableHeader: {
    backgroundColor: '#4caf50',
    color: 'white',
    cursor: 'pointer',
    padding: '10px',
    textAlign: 'left',
    border: '1px solid #ddd',
  },
  tableCell: {
    border: '1px solid #ddd',
    padding: '10px',
    textAlign: 'left',
  },
  paginationContainer: {
    textAlign: 'center',
    marginTop: '20px',
  },
  paginationButton: {
    backgroundColor: '#4caf50',
    color: 'white',
    border: 'none',
    padding: '10px 20px',
    margin: '0 5px',
    cursor: 'pointer',
    borderRadius: '5px',
  },
  sortButton: {
    backgroundColor: 'transparent',
    border: 'none',
    marginLeft: '5px',
    cursor: 'pointer',
    fontSize: '14px',
  },
};
