const express = require('express');
const { Pool } = require('pg');
const cors = require('cors'); // Import CORS middleware

const app = express();
const port = 3002;

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'koushik',
  password: 'yash',
  port: 5432,
});

app.use(cors()); // Enable CORS for all routes

app.get('/data', async (req, res) => {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT * FROM main');
    const rows = result.rows;
    client.release();
    console.log(rows); // Log fetched data
    res.json(rows);
  } catch (err) {
    console.error('Error executing query', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});
