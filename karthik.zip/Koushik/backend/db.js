const { Pool } = require('pg');

const pool = new Pool({
  user: 'your_username', // Replace with your database credentials
  host: 'your_host',
  database: 'your_database',
  password: 'your_password',
  port: 5432,
});

module.exports = pool;


